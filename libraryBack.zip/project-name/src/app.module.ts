import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { Book, BookSchema } from './schemas/book.schema';
import { BookAuthor, BookAuthorSchema } from './schemas/book_author_shcema';
import { Author, AuthorSchema } from './schemas/author_schema';

@Module({
  imports: [
    MongooseModule.forRoot(
      'mongodb://root:pass@localhost/library?authSource=admin',
    ),
    MongooseModule.forFeature([
      { name: Book.name, schema: BookSchema },
      { name: BookAuthor.name, schema: BookAuthorSchema },
      { name: Author.name, schema: AuthorSchema },
    ]),
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}

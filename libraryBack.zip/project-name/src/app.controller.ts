import { Get, Controller, Render, Put, Body, Param, Query } from '@nestjs/common';
import { AppService } from './app.service';
import CreateBookDto from './interfaces/CreateBookDto';

@Controller()
export class AppController {
  constructor(private readonly appService: AppService) {}

  // @Get('/')
  // @Render('index')
  // async getBooks() {
  //   return await this.appService.getPaginBooks(20, 1);
  // }

  @Get('/')
  @Render('index')
  async getPaginBooks(@Query('page') page: number) {
    // this.appService.getHello();
    return await this.appService.getPaginBooks(20, page);
  }

  @Get('/book/:book_id')
  @Render('index1')
  async getBook(@Param('book_id') book_id: string) {
    return await this.appService.getBook(book_id);
  }

  @Put('/add')
  @Render('index')
  add(@Body() createBookDto: CreateBookDto) {
    return this.appService.addNewBook(createBookDto);
  }
}

import { Book } from '../schemas/book.schema';

export default interface CreateAuthorDto {
  name: string;
}

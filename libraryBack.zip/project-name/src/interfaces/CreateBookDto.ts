export default interface CreateBookDto {
  id: string;
  title: string;
  author: string;
  image: string;
  link: string;
  year: string;
}

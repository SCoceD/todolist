export default interface CreateBookAuthorDto {
  authorId: string;
  name: string;
  bookId: string;
}

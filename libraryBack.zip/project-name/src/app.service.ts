import { Model } from 'mongoose';
import { Injectable, Query } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Book, BookDocument } from './schemas/book.schema';
import CreateBookDto from './interfaces/CreateBookDto';
import { Author, AuthorDocument } from './schemas/author_schema';

@Injectable()
export class AppService {
  constructor(
    @InjectModel(Book.name) private bookModel: Model<BookDocument>,
    @InjectModel(Author.name) private authorModel: Model<AuthorDocument>,
  ) {}

  async getPaginBooks(take?: number, page?: number) {
    const result = await this.bookModel
      .aggregate()
      .lookup({
        from: 'authors',
        localField: 'authorId',
        foreignField: '_id',
        as: 'author',
      })
      .exec();
    return {
      books: result.slice(
        page > 0 ? (page - 1) * take : 1,
        (page > 0 ? (page - 1) * take : 1) + take,
      ),
      page: page,
      prevPage: '?page=' + (page <= 1 ? 1 : (page - 1)),
      nextPage: '?page=' + (+page + 1),
    };
    // {
    //   books: await this.bookModel
    //     .find()
    //     .skip(page > 1 ? (page - 1) * take : 1)
    //     .limit(take),
    //   page: page,
    //   prevPage: '?page=' + (page - 1),
    //   nextPage: '?page=' + (+page + 1),
    // };
  }

  async getBook(book_id: string) {
    return { book: await this.bookModel.findOne({ id: book_id }) };
  }

  async addNewBook(createBookDto: CreateBookDto) {
    const createdBook = await new this.bookModel(createBookDto).save();
    let author = await this.authorModel.findOne({ name: createdBook.author });
    if (author) {
      await this.addAuthorIdToBook(createdBook, author);
      return createdBook.save();
    }
    author = await new this.authorModel({ name: createdBook.author }).save();
    await this.addAuthorIdToBook(createdBook, author);
    return createdBook.save();
  }

  async addAuthorIdToBook(createdBook, author) {
    await this.bookModel.updateMany(
      { author: createdBook.author },
      { authorId: author._id },
    );
  }

  async findAll(): Promise<Book[]> {
    return this.bookModel.find().exec();
  }
  async getHello() {
    await this.addNewBook({
      id: '22',
      title: 'СИ++ И КОМПЬЮТЕРНАЯ ГРАФИКА',
      author: 'Андрей Богуславский',
      image: './books/books-page/books-page_files/22.jpg',
      link: 'http://localhost:3000/book/22',
      year: '2003',
    });
    await this.addNewBook({
      id: '223',
      title: 'СiiiiiiiiiiiiiiiiiИ++ И КОМПЬЮТЕРНАЯ ГРАФИКА',
      author: 'Андрей Богуславский',
      image: './books/books-page/books-page_files/22.jpg',
      link: 'http://localhost:3000/book/22',
      year: '2003',
    });
    await this.addNewBook({
      id: '23',
      title: 'Програмирование на языке Go!',
      author: 'Марк Саммерфильд',
      image: './books/books-page/books-page_files/23.jpg',
      link: 'http://localhost:3000/book/23',
      year: '2002',
    });
    await this.addNewBook({
      id: '25',
      title: 'Толковый словарь сетевых теминов и аббревиатур',
      author: 'М. Вильямс',
      image: './books/books-page/books-page_files/25.jpg',
      link: 'http://localhost:3000/book/25',
      year: '2001',
    });
    await this.addNewBook({
      id: '26',
      title: 'Python for Data Analysis',
      author: 'Уэс Маккинни',
      image: './books/books-page/books-page_files/26.jpg',
      link: 'http://localhost:3000/book/26',
      year: '2000',
    });
    await this.addNewBook({
      id: '27',
      title: 'Thinking in Java (4th Edition)',
      author: 'Брюс Эккель',
      image: './books/books-page/books-page_files/27.jpg',
      link: 'http://localhost:3000/book/27',
      year: '2004',
    });
    await this.addNewBook({
      id: '29',
      title: 'Introduction to Algorithms',
      author: 'Томас Кормен',
      image: './books/books-page/books-page_files/29.jpg',
      link: 'http://localhost:3000/book/29',
      year: '2005',
    });
    await this.addNewBook({
      id: '31',
      title: 'JavaScript Pocket Reference',
      author: 'Давид Флэнаган',
      image: './books/books-page/books-page_files/31.jpg',
      link: 'http://localhost:3000/book/31',
      year: '2006',
    });
    await this.addNewBook({
      id: '32',
      title:
        'Adaptive Code via C#: Class and Interface Design, Design Patterns, and SOLID Principles',
      author: 'Гэри Маклин Холл',
      image: './books/books-page/books-page_files/32.jpg',
      link: 'http://localhost:3000/book/32',
      year: '2007',
    });
    await this.addNewBook({
      id: '33',
      title: 'SQL: The Complete Referenc',
      author: 'Джеймс Р. Грофф',
      image: './books/books-page/books-page_files/33.jpg',
      link: 'http://localhost:3000/book/33',
      year: '2008',
    });
    await this.addNewBook({
      id: '34',
      title: 'PHP and MySUL Web Development',
      author: 'Люк Веллинг',
      image: './books/books-page/books-page_files/34.jpg',
      link: 'http://localhost:3000/book/34',
      year: '2009',
    });
    await this.addNewBook({
      id: '35',
      title: 'Статистический анализ и визуализация данных с помощью R',
      author: 'Сергей Мастицкий',
      image: './books/books-page/books-page_files/35.jpg',
      link: 'http://localhost:3000/book/35',
      year: '2010',
    });
    await this.addNewBook({
      id: '36',
      title: 'Computer Coding for Kid',
      author: 'Джон Вудкок',
      image: './books/books-page/books-page_files/36.jpg',
      link: 'http://localhost:3000/book/36',
      year: '2011',
    });
    await this.addNewBook({
      id: '37',
      title: 'Exploring Arduino: Tools and Techniques for Engineering Wizardry',
      author: 'Джереми Блум',
      image: './books/books-page/books-page_files/37.jpg',
      link: 'http://localhost:3000/book/37',
      year: '2012',
    });
    await this.addNewBook({
      id: '38',
      title: 'Программирование  микроконтроллеров для начинающих и не только',
      author: 'А. Белов',
      image: './books/books-page/books-page_files/38.jpg',
      link: 'http://localhost:3000/book/38',
      year: '2013',
    });
    await this.addNewBook({
      id: '39',
      title: 'The Internet of Things',
      author: 'Сэмюэл Грингард',
      image: './books/books-page/books-page_files/39.jpg',
      link: 'http://localhost:3000/book/39',
      year: '2014',
    });
    await this.addNewBook({
      id: '40',
      title: 'Sketching User Experiences: The WorkBook',
      author: 'Сет Гринберг',
      image: './books/books-page/books-page_files/40.jpg',
      link: 'http://localhost:3000/book/40',
      year: '2015',
    });
    await this.addNewBook({
      id: '41',
      title: 'InDesign CS6',
      author: 'Александр Сераков',
      image: './books/books-page/books-page_files/41.jpg',
      link: 'http://localhost:3000/book/41',
      year: '2016',
    });
    await this.addNewBook({
      id: '42',
      title: 'Адаптивный дизайню Делаем Сайты для любых устройств',
      author: 'Тим Кедлек',
      image: './books/books-page/books-page_files/42.jpg',
      link: 'http://localhost:3000/book/42',
      year: '2017',
    });
    await this.addNewBook({
      id: '43',
      title: 'Android для разработчиков',
      author: 'Пол Дуйте, Хорви Дейтел',
      image: './books/books-page/books-page_files/43.jpg',
      link: 'http://localhost:3000/book/43',
      year: '2018',
    });
    await this.addNewBook({
      id: '44',
      title: 'Clean code: A Handbook of Agile Software Craftsmanship',
      author: 'Роберт Мартин',
      image: './books/books-page/books-page_files/44.jpg',
      link: 'http://localhost:3000/book/44',
      year: '2019',
    });
    await this.addNewBook({
      id: '45',
      title: 'Swift Pocket Reference: Programing for iOS X',
      author: 'Энтони Грей',
      image: './books/books-page/books-page_files/45.jpg',
      link: 'http://localhost:3000/book/45',
      year: '2020',
    });
    await this.addNewBook({
      id: '46',
      title:
        'NoSQL Distilled: A Brief Guide to the Emerging World of Polyglot Persistence',
      author: 'Мартин Фаулер',
      image: './books/books-page/books-page_files/46.jpg',
      link: 'http://localhost:3000/book/46',
      year: '2021',
    });
    await this.addNewBook({
      id: '47',
      title: 'Head First Ruby',
      author: 'Джей Макгаврен',
      image: './books/books-page/books-page_files/47.jpg',
      link: 'http://localhost:3000/book/47',
      year: '2022',
    });
    await this.addNewBook({
      id: '48',
      title: 'Practical Vin',
      author: 'Дрю Нейл',
      image: './books/books-page/books-page_files/48.jpg',
      link: 'http://localhost:3000/book/48',
      year: '2023',
    });
  }
}

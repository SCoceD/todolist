import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document, Schema as MongooseSchema } from 'mongoose';

export type BookDocument = Book & Document;

@Schema()
export class Book {
  @Prop()
  authorId: MongooseSchema.Types.ObjectId;

  @Prop()
  title: string;

  @Prop()
  id: string;

  @Prop()
  author: string;

  @Prop()
  image: string;

  @Prop()
  link: string;

  @Prop()
  year: string;
}

export const BookSchema = SchemaFactory.createForClass(Book);

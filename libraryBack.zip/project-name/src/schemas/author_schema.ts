import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';
import { Book } from './book.schema';

export type AuthorDocument = Author & Document;

@Schema()
export class Author {
  @Prop()
  authorId: string;

  @Prop()
  name: string;

  @Prop()
  books: Book[];
}

export const AuthorSchema = SchemaFactory.createForClass(Author);

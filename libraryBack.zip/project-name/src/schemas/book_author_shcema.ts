import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { Document } from 'mongoose';

export type BookAuthorDocument = BookAuthor & Document;

@Schema()
export class BookAuthor {
  @Prop()
  name: string;

  @Prop()
  bookId: string;
}

export const BookAuthorSchema = SchemaFactory.createForClass(BookAuthor);
